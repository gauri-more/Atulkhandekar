<!DOCTYPE html>
<html lang="en">
    <!--<< Header Area >>-->
    <head>

    <!-- Character Set -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Primary Meta Tags -->
    <title> Atul Khandekar | Hindustani Classical Vocalist | Natyasangeet Artist</title>

    <meta name="title" content=" Atul Khandekar | Hindustani Classical Vocalist">
    <meta name="description"
        content="Official website of  Atul Khandekar, renowned Hindustani Classical Vocalist, Natyasangeet exponent, performer, music educator and recipient of several prestigious national awards.">

    <meta name="keywords"
        content="Atul Khandekar,  Atul Khandekar, Hindustani Classical Singer, Classical Vocalist, Natyasangeet, Indian Classical Music, Marathi Singer, Classical Music Concerts, Pune Music Artist">

    <meta name="author" content=" Atul Khandekar">

    <meta name="robots" content="index, follow">
    <meta name="language" content="English">

    <!-- Canonical URL -->
    <link rel="canonical" href="https://www.atulkhandekar.com/">

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="assets/images/favicon.png">
    <link rel="apple-touch-icon" href="assets/images/favicon.png">

    <!-- Open Graph -->
    <meta property="og:type" content="website">
    <meta property="og:title" content=" Atul Khandekar | Hindustani Classical Vocalist">
    <meta property="og:description"
        content="Official website of  Atul Khandekar showcasing biography, concerts, awards, gallery, music journey and performances.">
    <meta property="og:image" content="https://www.atulkhandekar.com/assets/images/inner-img/atul-khandekar-about.jpg">
    <meta property="og:url" content="https://www.atulkhandekar.com/">
    <meta property="og:site_name" content=" Atul Khandekar">

    <!-- Twitter -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Atul Khandekar | Hindustani Classical Vocalist">
    <meta name="twitter:description"
        content="Official website of  Atul Khandekar - Hindustani Classical Vocalist and Natyasangeet Artist.">
    <meta name="twitter:image"
        content="https://www.atulkhandekar.com/assets/images/inner-img/atul-khandekar-about.jpg">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Marcellus&family=Outfit:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet">

    <!-- CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/all.min.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/meanmenu.css">
    <link rel="stylesheet" href="assets/css/swiper-bundle.min.css">
    <link rel="stylesheet" href="assets/css/nice-select.css">
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/css/style.css">
<script type="application/ld+json">
{
  "@context":"https://schema.org",
  "@type":"Person",
  "name":" Atul Khandekar",
  "jobTitle":"Hindustani Classical Vocalist",
  "url":"https://www.atulkhandekar.com/",
  "image":"https://www.atulkhandekar.com/assets/images/inner-img/atul-khandekar-about.jpg",
  "description":"Renowned Hindustani Classical Vocalist and Natyasangeet artist from India.",
  "sameAs":[
    "https://www.youtube.com/",
    "https://www.facebook.com/",
    "https://www.instagram.com/"
  ]
}
</script>
</head>
    <body class="body-bg-1">

        <!-- Back To Top Start -->
        <div class="preloader is-loading">
            <div class="preloader-inner">
                <div class="preloader-ball-wrap">
                    <div class="preloader-ball-inner-wrap">
                        <div class="preloader-ball-inner">
                            <div class="preloader-ball"></div>
                        </div>
                        <div class="preloader-ball-shadow"></div>
                    </div>
                    <div id="weave-anim" class="preloader-text">Atul Khandekar...</div>
                </div>
            </div>
            <div class="preloader-overlay"></div>
        </div>

         <!-- Back To Top Start -->
        <button id="back-top" class="back-to-top">
            <i class="fa-regular fa-arrow-up"></i>
        </button>

        <!-- GT MouseCursor Start -->
        <div class="mouseCursor cursor-outer"></div>
        <div class="mouseCursor cursor-inner"></div>

       <!-- Offcanvas Area Start -->
        <div class="fix-area">
            <div class="offcanvas__info">
                <div class="offcanvas__wrapper">
                    <div class="offcanvas__content">
                        <div class="offcanvas__top d-flex justify-content-between align-items-center">
                            <div class="offcanvas__logo">
                                <a href="index.php">
                                    <img src="assets/images/inner-img/atul_khandekar_logo_white.png" alt="logo-img">
                                </a>
                            </div>
                            <div class="offcanvas__close">
                                <button>
                                    <i class="fa-thin fa-times"></i>
                                </button>
                            </div>
                        </div>
                        <p class="text d-none d-xl-block">
                            Developing personalized charity journeys to increase donor satisfaction strengthen community 
                            trust and expand our humanitarian by global philanthropic.
                        </p>
                        <div class="mobile-menu fix"></div>
                        <div class="off-contact-info">
                            <span class="info-title">Contact Info</span>
                            <div class="contact-details">
                                <span class="sub-info">Phone</span>
                                <p>
                                    <a href="tel:+91 99 22 442438">+91 99 22 442438</a>
                                </p>
                            </div>
                            <div class="contact-details">
                                <span class="sub-info">Email</span>
                                <p>
                                    <a href="mailto:atulrkhandekar@gmail.com">atulrkhandekar@gmail.com</a>
                                </p>
                            </div>
                            <div class="contact-details">
                                <span class="sub-info">Location</span>
                                <p>
                                    96/89 Sadashiv Peth, 'Shilp'
Rajendra Nagar, Pune 411030, Maharashtra, India
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="social-icon-list">
                            <span class="follow-title">
                                Follow us:
                            </span>
                            <div class="social-icon d-flex align-items-center">
                                <a href="https://www.facebook.com/atulrkhandekar?fref=ts&ref=br_tf"><i class="fab fa-facebook-f"></i></a>
                                <!--<a href="#"><i class="fab fa-twitter"></i></a>-->
                            <a href="https://www.youtube.com/results?search_query=atul+khandekar"><i class="fab fa-youtube"></i></a>
                            </div>
                            
                        </div>
                </div>
            </div>
        </div>
        <div class="offcanvas__overlay"></div>

        <!-- Header Section Start -->
        <header id="header-sticky" class="header-3 header-4 header-9">
            <div class="container">
                <div class="mega-menu-wrapper">
                    <div class="header-main">
                            <a href="index.php" class="logo">
                                <img src="assets/images/inner-img/Atul-Khandekar-logo-vector.svg" class="site-logo"  alt="Atul Khandekar">
                            </a>
                            <div class="header-right d-flex justify-content-end align-items-center">
                                <div class="mean__menu-wrapper">
                                <div class="main-menu">
                                    <nav id="mobile-menu">
                                    <ul>
                                     <li>
                                            <a href="index.php">Home </a>
                                        </li>
                                        <li>
                                            <a href="about.php">About us</a>
                                        </li>
                                   <li>
                                            <a href="gallery.php">Gallery </a>
                                        </li>
                                         <li>
                                            <a href="awards.php">Awards </a>
                                        </li>
                                        <li>
                                            <a href="gurus-blessings.php">Guru's Blessings </a>
                                        </li>
                                        <li>
                                            <a href="reviews.php">Review </a>
                                        </li>
                                         <li>
                                            <a href="av.php">Audio-video </a>
                                        </li>
                                        <li>
                                            <a href="contact.php">Contact</a>
                                        </li>
                                    </ul>
                                </nav>
                                </div>
                            </div>
                            <a href="#" class="main-header__search search-toggler">
                                <i class="fa-regular fa-magnifying-glass"></i>
                            </a>
                            <button class="header-language-toggle notranslate" id="language-toggle" type="button" aria-label="Switch language to Marathi" aria-pressed="false" translate="no">
                                <i class="fa-solid fa-language" aria-hidden="true"></i>
                                <span class="language-toggle__en">EN</span>
                                <span class="language-toggle__divider">/</span>
                                <span class="language-toggle__mr">म</span>
                            </button>
                            <div class="header__hamburger d-xl-none my-auto">
                                <div class="sidebar__toggle">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        
        <!-- Search Start -->
        <div class="search-popup">
            <div class="search-popup__overlay search-toggler"></div>
            <div class="search-popup__content">
                <form role="search" method="get" class="search-popup__form" action="#">
                    <input type="text" id="search" name="search" placeholder="Search Here...">
                    <button type="submit" aria-label="search submit" class="search-btn">
                        <span><i class="fa-regular fa-magnifying-glass"></i></span>
                    </button>
                </form>
            </div>
        </div>
        <!-- Search Start -->
       

        <div id="smooth-wrapper">
            <div id="smooth-content">